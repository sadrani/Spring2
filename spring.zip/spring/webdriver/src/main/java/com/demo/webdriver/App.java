package com.demo.webdriver;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class App 
{
    public static void main( String[] args ) throws MalformedURLException, InterruptedException
    {

    	// create a Chrome Web Driver
    	URL local = new URL("http://localhost:9515");
    	WebDriver driver = new RemoteWebDriver(local, DesiredCapabilities.chrome());
    	// open the browser and go to open google.com
    	driver.get("https://www.google.com"); 
    	driver.manage().window().maximize();
    	//driver.wait(10);
    	driver.findElement(By.name("q")).sendKeys("Nikhil");
    	//driver.findElement(By.id("lst-ib")).sendKeys("Selenium");
    	driver.findElement(By.name("btnK")).click();
    	driver.manage().window().maximize();
    }
}
