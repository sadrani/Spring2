package com.demo;

import com.example.Example;

public class Demo {

	public static void main(String[] args) {
		Example obj = new Example("Nikhil",1,"London");
		System.out.println("Employee Details" + obj.getEmpName() + obj.getEmpId() + obj.getCity());	

	}

}
