package com.sort;

import java.util.ArrayList;
import java.util.List;

public class autosort implements Isort{
	List<Integer> lst = new ArrayList<Integer>();

	public void sortlogic(int[] arr) {
		for (int i : arr) {
			lst.add(i);
			}
		lst.sort(null);
		
		for (int j : lst) {
			System.out.println(j);

		}
		
	}

	
	}

