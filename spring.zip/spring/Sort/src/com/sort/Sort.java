package com.sort;

public class Sort {

	public static void main(String[] args) {
		int arr[] = { 10,9,8,6,5,4,2,1,3 };
		
		
		// TODO Auto-generated method stub
		bubblesort sort = new bubblesort();
		autosort auto1 = new autosort();
		auto1.sortlogic(arr);
		sort.sortlogic(arr);
		
		System.out.println("Array After Bubble Sort");
	      for(int i = 0; i < arr.length; i++) {
		         System.out.print(arr[i] + " ");

	      }
	}

}
