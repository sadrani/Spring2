package com.sort;

public interface Isort {
	void sortlogic(int[] arr);
}
