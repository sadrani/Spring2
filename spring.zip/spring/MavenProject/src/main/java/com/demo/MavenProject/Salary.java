package com.demo.MavenProject;

public class Salary {
	
	public Salary() {
	}
	private Integer sal;
	private Integer id;
	
	public Integer getSal() {
		return sal;
	}
	public void setSal(Integer sal) {
		this.sal = sal;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
	

}
