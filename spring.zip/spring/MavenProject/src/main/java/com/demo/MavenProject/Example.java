package com.demo.MavenProject;


public class Example {
	
	public Example() {
		
	}
	
	private String empName;
	private Integer empId;
	private String city;
	private Salary salary;
	
	
	public Example(String name,Integer id, String city){
		this.empName = name;
		this.empId = id;
		this.city = city;
	}
	
	
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}



	public Salary getSalary() {
		return salary;
	}



	public void setSalary(Salary salary) {
		this.salary = salary;
	}



	
	
	

}
