package com.demo.MavenProject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {
	public static void main(String[] args) {
		 ApplicationContext context = new ClassPathXmlApplicationContext("Application-context.xml");
	      Example obj = (Example) context.getBean("example");
	      obj.getCity();
	      System.out.println("success" + obj.getSalary().getSal());
	      System.out.println("example" + obj.getEmpName());
			

	}
	

}
