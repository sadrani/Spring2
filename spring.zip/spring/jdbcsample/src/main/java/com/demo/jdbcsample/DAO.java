package com.demo.jdbcsample;

public interface DAO {
	public void insert (Customer customer);
	public Customer findcustomer(int custId);

}
