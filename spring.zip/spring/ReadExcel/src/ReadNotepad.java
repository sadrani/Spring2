import java.io.IOException;

public class ReadNotepad {

	public static void main(String[] args) throws IOException {
Read r = new Read();
r.readfile();
r.writefile();
r.readfile();

	}

}
