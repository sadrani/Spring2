import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class Read 
{
	String filename = "C:\\Users\\nsadrani\\spring\\ReadExcel\\src\\myfile.txt";
	String line="";
	List<String> r = new ArrayList<String>(); 

	public void readfile() throws IOException {
		r.clear();
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		  while((line = reader.readLine()) != null){ 
			 r.add(line);
		  }
		  
		  for (String string : r) 
		  {
			  System.out.println(string);
		  }
		}
		  
		 public void writefile() throws FileNotFoundException, UnsupportedEncodingException
		 {
			 PrintWriter writer = new PrintWriter("C:\\Users\\nsadrani\\spring\\ReadExcel\\src\\myfile.txt", "UTF-8");
			 writer.println("The clear  line");
			 writer.println("The  clean line");
			 writer.close();
		 }
	
	
}
