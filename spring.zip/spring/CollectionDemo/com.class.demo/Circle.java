import java.util.ArrayList;
import java.util.List;

import Shapes.Construction;
import Shapes.Shapes;

public class Circle implements Shapes, Construction {

	ArrayList<String> cars = new ArrayList<String>();
    
	
	@Override
	public void draw() {
		cars.add("Volvo");
	    cars.add("BMW");
	    cars.add("Ford");
	    cars.add("Mazda");
	    System.out.println(cars);	
System.out.println("i am in draw circle");	
System.out.println(cars.get(2));
for (String string : cars) {
	System.out.println(string);
	
}
System.out.println(cars.size());
cars.addAll(2,cars);
System.out.println(cars);
	}

	@Override
	public void delete() {
		System.out.println("i am in delete circle");		
		
	}

	@Override
	public void Create() {
		System.out.println("i am in create circle");		
		
	}

	


}
