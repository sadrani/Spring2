import Shapes.Shapes;

public class Square implements Shapes {

	@Override
	public void draw() {
		System.out.println("i am in draw Square");		
		
	}

	@Override
	public void delete() {
		System.out.println("i am in delete square");		
		
	}

}
