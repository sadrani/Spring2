
public class Diagram {

	public static void main(String[] args) {
		Circle c = new Circle();
		Square s = new Square();
c.draw();
s.delete();
c.Create();

	}

}