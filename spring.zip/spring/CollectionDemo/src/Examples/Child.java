package Examples;

import Examples1.Parent;

public class Child extends Parent {
	Parent p = new Parent();
	
	
	@Override
	public String getStr1() {
		// TODO Auto-generated method stub
		return super.getStr1();
	}
	
}
