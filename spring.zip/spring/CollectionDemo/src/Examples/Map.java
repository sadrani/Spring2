package Examples;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Collection value = new ArrayList<>();
		value.add(5);
		value.add(5);
		value.add(5);
		
		
		System.out.println(value);
		
		HashMap<String, String> capitalCities = new HashMap<String, String>();
		capitalCities.put("London","England");
		capitalCities.put("Delhi","India");
		capitalCities.put("Madrid","Spain");
		capitalCities.put("Berlin","Germany");
System.out.println(capitalCities.get("Delhi"));
	}

}
