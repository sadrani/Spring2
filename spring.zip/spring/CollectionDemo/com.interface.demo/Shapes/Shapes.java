package Shapes;

public interface Shapes {
	 void draw();
	 void delete();
	 
	Integer num = 0;
	

}
