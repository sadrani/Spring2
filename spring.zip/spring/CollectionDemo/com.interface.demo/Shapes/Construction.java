package Shapes;

public interface Construction {
	void Create();
	

}
